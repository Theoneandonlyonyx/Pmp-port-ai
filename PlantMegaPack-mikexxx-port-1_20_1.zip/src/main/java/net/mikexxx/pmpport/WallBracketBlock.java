package net.mikexxx.pmpport;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Small shelf bracket mounted on the side of a block. FACING points away from the wall. */
public class WallBracketBlock extends HorizontalDirectionalBlock {
    private static final VoxelShape SOUTH = Block.box(4, 0, 0, 12, 8, 9);
    private static final VoxelShape NORTH = Block.box(4, 0, 7, 12, 8, 16);
    private static final VoxelShape EAST = Block.box(0, 0, 4, 9, 8, 12);
    private static final VoxelShape WEST = Block.box(7, 0, 4, 16, 8, 12);

    public WallBracketBlock(Properties p) {
        super(p);
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.SOUTH));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
        b.add(FACING);
    }

    @Override
    public VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
        return switch (s.getValue(FACING)) {
            case NORTH -> NORTH;
            case EAST -> EAST;
            case WEST -> WEST;
            default -> SOUTH;
        };
    }

    @Override
    public boolean canSurvive(BlockState s, LevelReader l, BlockPos p) {
        Direction back = s.getValue(FACING).getOpposite();
        BlockPos bp = p.relative(back);
        return l.getBlockState(bp).isFaceSturdy(l, bp, back.getOpposite());
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext c) {
        for (Direction d : c.getNearestLookingDirections()) {
            if (d.getAxis().isHorizontal()) {
                BlockState s = defaultBlockState().setValue(FACING, d.getOpposite());
                if (s.canSurvive(c.getLevel(), c.getClickedPos())) return s;
            }
        }
        return null;
    }

    @Override
    public BlockState updateShape(BlockState s, Direction d, BlockState n, LevelAccessor l, BlockPos p, BlockPos np) {
        return !s.canSurvive(l, p) ? Blocks.AIR.defaultBlockState() : s;
    }
}
