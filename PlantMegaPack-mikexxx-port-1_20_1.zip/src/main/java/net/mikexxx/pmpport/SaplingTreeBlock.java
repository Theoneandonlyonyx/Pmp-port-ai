package net.mikexxx.pmpport;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.registries.ForgeRegistries;

/** Sapling: grows into a tree on random ticks / bone meal (honeycomb-waxed saplings never grow). */
public class SaplingTreeBlock extends PlantBlock {
    private final String logId, leafId;
    private final boolean conifer;
    private final int height;

    public SaplingTreeBlock(Properties p, String logId, String leafId, boolean conifer, int height) {
        super(p, 0, Type.GROUND);
        this.logId = logId;
        this.leafId = leafId;
        this.conifer = conifer;
        this.height = height;
    }

    private void tryGrow(ServerLevel level, BlockPos pos, RandomSource r) {
        Block log = ForgeRegistries.BLOCKS.getValue(new ResourceLocation(logId));
        Block leaf = ForgeRegistries.BLOCKS.getValue(new ResourceLocation(leafId));
        if (log == null || leaf == null) return;
        TreeGen.grow(level, pos, log, leaf, conifer, height, r);
    }

    @Override
    public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (state.getValue(WAXED)) return;
        if (level.getRawBrightness(pos, 0) >= 9 && random.nextInt(7) == 0) tryGrow(level, pos, random);
    }

    @Override
    public boolean isValidBonemealTarget(LevelReader level, BlockPos pos, BlockState state, boolean client) {
        return !state.getValue(WAXED);
    }

    @Override
    public boolean isBonemealSuccess(Level level, RandomSource r, BlockPos pos, BlockState state) {
        return r.nextFloat() < 0.45F;
    }

    @Override
    public void performBonemeal(ServerLevel level, RandomSource r, BlockPos pos, BlockState state) {
        tryGrow(level, pos, r);
    }
}
