# PlantMegaPack mikexxx port (Forge 1.20.1)
Upload this folder (or the zip) to a GitHub repo -> Actions tab -> "build-jar" -> download the jar artifact.
Honeycomb on a plant = waxed (stops growing). Axe removes wax. Bone meal = +1 growth stage.

Added in this revision:
- Planters (59), flower pots (32), wall brackets (26 incl. 1.7.10 stone/gem ones), bamboo poles (9), bamboo walls (9),
  fruitwood bark, potting table (opens a 3x3 crafting grid).
- 241 crafting recipes converted from the 1.12.2 version (+ item tags food_vegetable/fruit/berry/nut/rice/bread/mushroom).
- Latin names for all species/cultivar plants (shown as grey italic tooltip).

Not ported: world generation, advancements, trellis / trellis tower (no assets in the 1.12.2 jar), curled brackets, cactus spike items.
